import axios from 'axios'
import React, { useState } from 'react'
import { useEffect } from 'react'
import { useParams } from 'react-router'
import styles from "./Individual.module.css"
import { 
    Box, 
    Image, 
    Flex, 
    Text, 
    Radio, 
    Heading, 
    Divider, 
    Button, 
    GridItem, 
    Grid, 
  } from "@chakra-ui/react"; 

  import { StarIcon } from "@chakra-ui/icons";

export const IndividualPage = () => {
const [data,setData]=useState([])
const [filterdata,setfilterdata]=useState({})
const {id} = useParams()
 const loderData = async () => {
        return await axios
          .get("https://shy-puce-cod-hose.cyclic.app/mens")
          .then((res) =>console.log(res,"response******************"))
          .catch((err) => console.log(err))
      }
      console.log(data,"individual")



    useEffect(()=>{
        loderData()
    },[])

// const store=data.filter((el)=>{
//     return(
//         el["_id"]==id
//     )

// }

// )
 console.log(data)

  return (
    <Box>
        <Grid templateColumns={['repeat(1, 1fr)', 'repeat(3, 1fr)']}  className={styles.mainBox}>
      <GridItem >
        
           <Image src={store[0].url} alt="product" />
      
      </GridItem >

      <GridItem display={["none", "inline"]}  >
        <Image  src={store[0].url} />
      </GridItem >

      <GridItem  className={styles.TextBar}  p="1rem">
        <Box>
          <Heading as="h2" size="lg">
            {store[0].brand}
          </Heading>
        </Box>
        {/* <Box>
          <Heading as="h2" size="2xl">
            {store[0].title}
          </Heading>
        </Box> */}
        <Box>
          <Text>A powerfull face serum that deeply hydrates skin</Text>
        </Box>

        <Flex>
          <Text>
            {Array(5)
              .fill("")
              .map((_, i) => (
                <StarIcon
                  key={i}
                  color={
                    i < Math.floor(Number(store[0].rating))
                      ? "yellow.500"
                      : "gray.300"
                  }
                />
              ))}
          </Text>
          <Text>  Reviews</Text>
        </Flex>

        <Flex>
          <Image
            width="50px"
            src="https://as1.ftcdn.net/v2/jpg/03/95/04/78/1000_F_395047812_kmXO1JBQKNqWeOQSCTvagAm30wnaWkz7.jpg"
            alt="star"
          />
          <Text as="b">
            Earn 530 reward and points when purchasing this product as a reward
            member
          </Text>
        </Flex>

        <Box>
          <Box border="1px solid" mb="5px">
            <Box>
             <Text>
             <Radio
                border={"1px solid red"}
                justifyContent={"flex-start"}
                value="1"
              >
                {store[0].price}
              </Radio>{" "}
              One Time Purchase
             </Text>
            </Box>
          </Box>

          {/* <Box alignItems={"flex-start"} border="1px solid "><Text  >{obj.currentSku.listPrice}</Text> </Box> */}

          <Box border="1px solid ">
           <Text>
           <Radio justifyContent={"flex-start"} value="1">
              {store[0].price}
            </Radio>{" "}
            Auto-Replenish
           </Text>
          </Box>

        </Box>

        <Box>
          <Heading as="h2" size="xl">
            {}
          </Heading>
        </Box>

        <Divider />
        <Text textAlign={"start"} border={"1px solid"} mb="8px">
          Quantity
        </Text>
        <Flex>
          <Box>
            {/* <Button
              disabled={quntity === 1}
              onClick={() => {
                setQuntity(quntity - 1);
              }}
              borderRadius={"0px"}
              border={"1px solid "}
            >
              -
            </Button> */}
            {/* <Button borderRadius={"0px"}>{quntity}</Button>
            <Button
              disabled={quntity === 8}
              onClick={() => setQuntity(quntity + 1)}
              borderRadius={"0px"}
              border={"1px solid "}
            >
              +
            </Button> */}
          </Box>
          <Box>
            <Button onClick={handelAddtocart} bg="blue.900" color="white" borderRadius={"0px"}>
              ADD TO CART
            </Button>
          </Box>
        </Flex>

        <Divider />

        <Box textAlign="start">
        <Button borderRadius={"0px"} >
          Double Points + $ 16 Gifts
        </Button>
        </Box>

        <Box>
          <Text>
            Earn 2x Dermstore Rewards Points on EltaMD. 2x points = 10% back in
            rewards to spend on future purchases at Dermstore.com. Plus, receive
            an EltaMD UV Restore Tinted 0.5 oz deluxe ($16 value) when you spend
            $75 or more on the brand. Participating products only. EltaMD event
            ends 11/11/22 at 11:59 p.m. PT.
          </Text>
        </Box>

        <Box  textAlign="start">
        <Button borderRadius={"0px"} border={"1px solid"}>
          START EARNING
        </Button>
        </Box>
      </GridItem >
    </Grid>
    <Divider />

    </Box>
  )
}
